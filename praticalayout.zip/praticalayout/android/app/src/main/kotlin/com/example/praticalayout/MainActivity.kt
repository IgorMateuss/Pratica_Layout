package com.example.praticalayout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
