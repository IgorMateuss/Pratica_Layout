import 'package:flutter/material.dart';
import 'package:praticalayout/MyApp.dart';
import 'package:praticalayout/LayoutCard.dart';

void main() {
  runApp(MaterialApp(
    home: MyApp(),
    //home: LayoutCard(),
  ));

}
