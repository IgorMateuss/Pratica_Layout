import 'package:flutter/material.dart';

class LayoutCard extends StatefulWidget {
  LayoutCard({Key? key}) : super(key: key);

  @override
  _LayoutCardState createState() => _LayoutCardState();
}

class _LayoutCardState extends State<LayoutCard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Page"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverList(
            delegate:
            SliverChildBuilderDelegate((BuildContext context, int index) {
              return Container(
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(bottom: 30),
                      child: Image.asset("imagens/Astronauta_1.jpg"),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 30),
                      //ignore: deprecated_member_use
                      child: RaisedButton(
                        padding: EdgeInsets.all(15),
                        child: Text(
                          "Delete",
                          style: TextStyle(fontSize: 10),
                        ),
                        onPressed: () {},
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 30),
                      child: Image.asset("imagens/Astronauta_2.jpg"),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 30),
                      //ignore: deprecated_member_use
                      child: RaisedButton(
                        padding: EdgeInsets.all(15),
                        child: Text(
                          "Delete",
                          style: TextStyle(fontSize: 10),
                        ),
                        onPressed: () {},
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 30),
                      child: Image.asset("imagens/Astronauta_3.jpg"),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 30),
                      //ignore: deprecated_member_use
                      child: RaisedButton(
                        padding: EdgeInsets.all(15),
                        child: Text(
                          "Delete",
                          style: TextStyle(fontSize: 10),
                        ),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}
